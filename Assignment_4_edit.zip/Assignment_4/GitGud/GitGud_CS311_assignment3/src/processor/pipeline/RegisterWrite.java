package processor.pipeline;

import generic.Simulator;
import processor.Processor;

public class RegisterWrite {
	Processor containingProcessor;
	MA_RW_LatchType MA_RW_Latch;
	IF_EnableLatchType IF_EnableLatch;
	EX_MA_LatchType EX_MA_Latch;
	
	public RegisterWrite(Processor containingProcessor, MA_RW_LatchType mA_RW_Latch, IF_EnableLatchType iF_EnableLatch, EX_MA_LatchType eX_MA_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.MA_RW_Latch = mA_RW_Latch;
		this.IF_EnableLatch = iF_EnableLatch;
		this.EX_MA_Latch = eX_MA_Latch;
	}
	
	public void performRW()
	{
		//TODO
		ControlSignals controlSignals = MA_RW_Latch.getControlSignals();
		int pc = MA_RW_Latch.getPc();
		int ldResult = MA_RW_Latch.getLdResult();
		long aluResult = MA_RW_Latch.getAluResult();
		int instruction = MA_RW_Latch.getInstruction();

		//===============================
        //DEBUG
        if(instruction != 0)
            controlSignals.display();
        else
            System.out.println();
        //===============================

		// controlSignals.display();

		if(MA_RW_Latch.isRW_enable()) {
			if(instruction == 0) {
				// MA_RW_Latch.setInstruction(0);
                return;
            }

			if(!controlSignals.getControlSignal(ControlSignals.OperationSignals.END.ordinal())) {
				boolean isAluResOverflow = true;
				RegisterFile regFileCopy = containingProcessor.getRegisterFile();

				if(instruction != 0)
					containingProcessor.instructionCount += 1;
				System.out.println(containingProcessor.instructionCount);

				//NOTE NOTE NOTE NOTE
				if(instruction == 0) {
					containingProcessor.nopCount += 1;
					// System.out.println("NOP!!!!");
					return;
				}

				if((aluResult >>> 32) == 0 || (aluResult >>> 32) == 0x00000000ffffffffL)
					isAluResOverflow = false;

				if(controlSignals.getControlSignal(ControlSignals.OperationSignals.WB.ordinal())) {
					if(isAluResOverflow || controlSignals.getControlSignal(ControlSignals.OperationSignals.DIV.ordinal())) {
						containingProcessor.regLockVector[31] -= 1;
						containingProcessor.regWriteCurrentCycle[31] = true;
						regFileCopy.setValue(31, (int) (aluResult >>> 32));
					}

					if(controlSignals.getControlSignal(ControlSignals.OperationSignals.LOAD.ordinal())) {
						int rd = (instruction << 10) >>> 27;
						regFileCopy.setValue(rd, ldResult);
						containingProcessor.regLockVector[rd] -= 1;
						containingProcessor.regWriteCurrentCycle[rd] = true;
					}

					else if (controlSignals.getControlSignal(ControlSignals.OperationSignals.IMMEDIATE.ordinal())) {
						int rd = (instruction << 10) >>> 27;
						regFileCopy.setValue(rd, (int) aluResult);
						containingProcessor.regLockVector[rd] -= 1;
						containingProcessor.regWriteCurrentCycle[rd] = true;
					}

					else {
						int rd = (instruction << 15) >>> 27;
						regFileCopy.setValue(rd, (int) aluResult);
						containingProcessor.regLockVector[rd] -= 1;
						containingProcessor.regWriteCurrentCycle[rd] = true;
						if(isAluResOverflow)
							regFileCopy.setValue(31, (int) (aluResult >>> 32));
						containingProcessor.setRegisterFile(regFileCopy);
					}
				}
			}
			else {
				MA_RW_Latch.setRW_enable(false);
				EX_MA_Latch.setMA_enable(false);
				containingProcessor.setIdle(true);
				// if(controlSignals.getControlSignal(ControlSignals.OperationSignals.END.ordinal())) {
				containingProcessor.endEncountered = true;
				// }
			}
		}
		// MA_RW_Latch.setRW_enable(false);
		// EX_MA_Latch.setMA_enable(true);
	}
}
