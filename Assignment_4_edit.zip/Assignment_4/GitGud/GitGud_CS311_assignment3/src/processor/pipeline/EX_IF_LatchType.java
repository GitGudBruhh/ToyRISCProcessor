package processor.pipeline;

public class EX_IF_LatchType {
	
	//added branchPC, controlSignals (use only isBranchTaken)
	int branchPC;
	ControlSignals controlSignals;
	public ControlSignals cSig_buf;

	public EX_IF_LatchType()
	{
		this.controlSignals = new ControlSignals();
		this.cSig_buf = new ControlSignals();
	}

	public int getBranchPC() {
		return this.branchPC;
	}

	public void setBranchPC(int branchPC) {
		this.branchPC = branchPC;
	}

	public ControlSignals getControlSignals() {
		return this.controlSignals;
	}

	public void setControlSignals(ControlSignals controlSignals) {
		this.controlSignals = controlSignals;
	}

	public void setControlSignalsBuf(ControlSignals controlSignals) {
		this.cSig_buf = controlSignals;
	}

	public void writeControlSigBuf() {
		controlSignals = cSig_buf;
	}

	public void clearLatch() {
		branchPC = 0;
		cSig_buf = new ControlSignals();
		controlSignals = new ControlSignals();;
	}

	public void clearLatch_not_buf() {
		// branchPC = 0;
		// cSig_buf = new ControlSignals();
		// controlSignals = new ControlSignals();;
	}
}
