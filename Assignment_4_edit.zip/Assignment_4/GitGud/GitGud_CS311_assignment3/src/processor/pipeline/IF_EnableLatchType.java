package processor.pipeline;

public class IF_EnableLatchType {
	
	boolean IF_enable;
	boolean isIgnore;
	
	public IF_EnableLatchType()
	{
		IF_enable = true;
	}

	public boolean isIF_enable() {
		return IF_enable;
	}

	public void setIF_enable(boolean iF_enable) {
		IF_enable = iF_enable;
	}

	public void printEnable() {
		System.out.print("IF: ");
		System.out.println(IF_enable);
	}

	// public boolean isIgnore() {
	// 	return this.isIgnore;
	// }
 //
	// public void setIgnore(ignore) {
	// 	this.isIgnore = ignore;
	// }

}
