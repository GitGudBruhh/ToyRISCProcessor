package processor.pipeline;

public class OF_EX_LatchType {
	
	boolean EX_enable;
	//added pc, branchTarget, immediates B(immx vs op2), A(op1), operand2, instruction and control signals
	int pc;
	int branchTarget; //goes to - IF - decided by - isRet ????
	int B; //comes from - immx vs (op2 from register file) - decided by - isImmediate
	int A; //comes from - op1
	int op2;
	int instruction;
	int writeRegNo;
	boolean is_31_write;
	ControlSignals controlSignals;

	boolean isIgnore;

	public OF_EX_LatchType()
	{
		EX_enable = false;
		isIgnore = true;
		controlSignals = new ControlSignals();
	}

	public boolean isEX_enable() {
		return EX_enable;
	}

	public void setEX_enable(boolean eX_enable) {
		EX_enable = eX_enable;
	}

	public int getInstruction() {
		return instruction;
	}

	public void setInstruction(int instruction) {
		this.instruction = instruction;
	}

	public int getPc() {
		return this.pc;
	}

	public void setPc(int pc) {
		this.pc = pc;
	}

	public int getBranchTarget() {
		return this.branchTarget;
	}

	public void setBranchTarget(int branchTarget) {
		this.branchTarget = branchTarget;
	}

	public int getB() {
		return this.B;
	}

	public void setB(int B) {
		this.B = B;
	}

	public int getA() {
		return this.A;
	}

	public void setA(int A) {
		this.A = A;
	}

	public int getOp2() {
		return this.op2;
	}

	public void setOp2(int op2) {
		this.op2 = op2;
	}

	public ControlSignals getControlSignals() {
		return this.controlSignals;
	}

	public void setControlSignals(ControlSignals controlSignals) {
		this.controlSignals = controlSignals;
	}

	public void printEnable() {
		System.out.print("EX: ");
		System.out.println(EX_enable);
	}

	public void setWriteRegNo(int r) {
		writeRegNo = r;
	}

	public int getWriteRegNo() {
		return writeRegNo;
	}

	public void setIs_31_write(boolean b) {
		is_31_write = b;
	}

	public boolean getIs_31_write() {
		return is_31_write;
	}

	public void clearLatch() {
		pc = 0;
		branchTarget = 0;
		B = 0;
		A = 0;
		op2 = 0;
		instruction = 0;
		writeRegNo = 0;
		is_31_write = false;
		controlSignals = new ControlSignals();;
	}
	// public boolean isIgnore() {
	// 	return this.isIgnore;
	// }
 //
	// public void setIgnore(ignore) {
	// 	this.isIgnore = ignore;
	// }
}
