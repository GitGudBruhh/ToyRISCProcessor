package processor.pipeline;

public class ControlInterlock {
    boolean branchInExTaken;
    // int branchStage;
    int branchPC;

    public ControlInterlock() {
        this.branchInExTaken = false;
        // branchStage = new int;
    }

    public boolean isBranchInExTaken() {
        return this.branchInExTaken;
    }

    public void setBranchInExTaken(boolean branchTaken) {
        this.branchInExTaken = branchTaken;
    }

    public int getBranchPC() {
        return this.branchPC;
    }

    public void setBranchPC(int b_pc) {
        this.branchPC = b_pc;
    }
}