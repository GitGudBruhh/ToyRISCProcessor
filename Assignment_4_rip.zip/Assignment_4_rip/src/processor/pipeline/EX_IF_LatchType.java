package processor.pipeline;

public class EX_IF_LatchType {
	
	//added branchPC, controlSignals (use only isBranchTaken)
	int branchPC;
	int branchPCBuf;
	ControlSignals controlSignals;
	ControlSignals controlSignalsBuf;

	public EX_IF_LatchType(ControlSignals c_Sig)
	{
		this.controlSignals = c_Sig;
		this.controlSignals = new ControlSignals();
		controlSignals.setMiscSignal(ControlSignals.MiscSignals.IGNORE.ordinal(), true);

	}

	public int getBranchPC() {
		return this.branchPC;
	}

	public void setBranchPC(int branchPC) {
		this.branchPC = branchPC;
	}

	public int getBranchPCBuf() {
		return this.branchPCBuf;
	}

	public void setBranchPCBuf(int branchPCBuf) {
		this.branchPCBuf = branchPCBuf;
	}

	public ControlSignals getControlSignals() {
		return this.controlSignals;
	}

	public void setControlSignals(ControlSignals controlSignals) {
		this.controlSignals = controlSignals;
	}

	public ControlSignals getControlSignalsBuf() {
		return this.controlSignalsBuf;
	}

	public void setControlSignalsBuf(ControlSignals controlSignalsBuf) {
		this.controlSignalsBuf = controlSignalsBuf;
	}

}
