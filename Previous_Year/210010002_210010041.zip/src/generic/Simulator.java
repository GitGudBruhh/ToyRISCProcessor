package generic;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.io.ByteArrayInputStream;
public class Simulator {
	static HashMap <String,String> map = new HashMap<String,String>(){{
		put("add","00000");
		put("addi","00001");
		put("sub","00010");
		put("subi","00011");
		put("mul","00100");
		put("muli","00101");
		put("div","00110");
		put("divi","00111");
		put("and","01000");
		put("andi","01001");
		put("or","01010");
		put("ori","01011");
		put("xor","01100");
		put("xori","01101");
		put("slt","01110");
		put("slti","01111");
		put("sll","10000");
		put("slli","10001");
		put("srl","10010");
		put("srli","10011");
		put("sra","10100");
		put("srai","10101");
		put("load","10110");
		put("store","10111");
		put("jmp","11000");
		put("beq","11001");
		put("bne","11010");
		put("blt","11011");
		put("bgt","11100");
		put("end","11101");
	 }};
		
	static FileInputStream inputcodeStream = null;
	static int firstCodeAddress;
	
	public static void setupSimulation(String assemblyProgramFile)
	{	
		firstCodeAddress = ParsedProgram.parseDataSection(assemblyProgramFile);
		ParsedProgram.parseCodeSection(assemblyProgramFile, firstCodeAddress);
		ParsedProgram.printState();

	}
	private static String toBinaryOfSpecificPrecision(int num, int lenOfTargetString) {
		String binary = String.format("%" + lenOfTargetString + "s", Integer.toBinaryString(num)).replace(' ', '0');
		return binary;
	}
	
	public static void assemble(String objectProgramFile)
	{
		FileOutputStream file;
		
		//TODO your assembler code
		//1. open the objectProgramFile in binary mode
		//2. write the firstCodeAddress to the file
		//3. write the data to the file
		//4. assemble one instruction at a time, and write to the file
		//5. close the file
		try {
			file= new FileOutputStream(objectProgramFile);
			file.write(ByteBuffer.allocate(4).putInt(firstCodeAddress).array());

	        for (int i = 0; i < ParsedProgram.data.size(); i++) {
	        	file.write(ByteBuffer.allocate(4).putInt(ParsedProgram.data.get(i)).array());

	        }
	        for (int i = 0; i < ParsedProgram.code.size(); i++) {
	        	String inst="";
	        	String optype=(ParsedProgram.code.get(i).operationType).toString();
				String opcode=map.get(ParsedProgram.code.get(i).getOperationType().toString()).toString();
				inst+=opcode;
				int op=Integer.parseInt(map.get(optype),2);
				int pc=ParsedProgram.code.get(i).getProgramCounter();
				if(op<22 && op%2!=0){
					String imx=toBinaryOfSpecificPrecision(ParsedProgram.code.get(i).getSourceOperand2().getValue(),17);
					String s2=toBinaryOfSpecificPrecision(ParsedProgram.code.get(i).getSourceOperand1().getValue(), 5);
					String d1=toBinaryOfSpecificPrecision(ParsedProgram.code.get(i).getDestinationOperand().getValue(), 5);
					inst=inst+s2+d1+imx;
				}
				else if(op<22 && op%2==0){
					String s1=toBinaryOfSpecificPrecision(ParsedProgram.code.get(i).getSourceOperand1().getValue(),5);
					String s2=toBinaryOfSpecificPrecision(ParsedProgram.code.get(i).getSourceOperand2().getValue(), 5);
					String d1=toBinaryOfSpecificPrecision(ParsedProgram.code.get(i).getDestinationOperand().getValue(), 5);
					String unu=toBinaryOfSpecificPrecision(0, 12);
					inst=inst+s1+s2+d1+unu;
				}
				
				else if(op==29) {
					String s1=toBinaryOfSpecificPrecision(0, 27);
					inst+=s1;
				}
				else if(op==22 || op==23) {
					String s1=toBinaryOfSpecificPrecision(ParsedProgram.code.get(i).getSourceOperand1().getValue(),5);
					String s2=toBinaryOfSpecificPrecision(ParsedProgram.code.get(i).getSourceOperand2().getValue(), 17);
					String d1=toBinaryOfSpecificPrecision(ParsedProgram.code.get(i).getDestinationOperand().getValue(), 5);
					inst=inst+s1+d1+s2;
				}
				else if(op>24 && op<29) {
					String s1=toBinaryOfSpecificPrecision(ParsedProgram.code.get(i).getSourceOperand1().getValue(),5);
					String s2=toBinaryOfSpecificPrecision(ParsedProgram.code.get(i).getSourceOperand2().getValue(), 5);
					int value= Integer.parseInt(toBinaryOfSpecificPrecision(ParsedProgram.symtab.get(ParsedProgram.code.get(i).getDestinationOperand().getLabelValue()),5),2)-pc;
					String bin = toBinaryOfSpecificPrecision(value, 17);
					String immx= bin.substring(bin.length() - 17);
					inst=inst+s1+s2+immx;
				}
				else if(op==24) {
					if(ParsedProgram.code.get(i).destinationOperand.getOperandType()==Operand.OperandType.Register) {
						int value= Integer.parseInt(toBinaryOfSpecificPrecision(ParsedProgram.symtab.get(ParsedProgram.code.get(i).getDestinationOperand().getLabelValue()),5),2)-pc;
						String bin = toBinaryOfSpecificPrecision(value, 17);
						String immx= bin.substring(bin.length() - 17);
					String unu=toBinaryOfSpecificPrecision(0, 10);
					inst=inst+immx+unu;
					}
					else {
						int value= Integer.parseInt(toBinaryOfSpecificPrecision(ParsedProgram.symtab.get(ParsedProgram.code.get(i).getDestinationOperand().getLabelValue()),5),2)-pc;
						String bin = toBinaryOfSpecificPrecision(value, 22);
						String immx= bin.substring(bin.length() - 22);
						String unu=toBinaryOfSpecificPrecision(0, 5);
						inst=inst+unu+immx;
					}
					}
				int intinst=(int) Long.parseLong(inst,2);
				file.write(ByteBuffer.allocate(4).putInt(intinst).array());
	        }
	        file.close();
			}
			catch(IOException ex) {
			System.out.println(
			"System is unable to create the file "
			+ objectProgramFile  + "'");
		
	}
	
}}
