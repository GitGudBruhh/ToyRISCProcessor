package processor.memorysystem;

import configuration.Configuration;
import generic.Element;
import generic.Event;
import generic.ExecutionCompleteEvent;
import generic.MemoryReadEvent;
import generic.MemoryResponseEvent;
import generic.MemoryWriteEvent;
import generic.Simulator;
import processor.Clock;
import processor.Processor;

public class Cache implements Element{
    int cachesize;
    boolean hit;
    float Associativity;
    int Latency;
    int line_size;
    int missed_addr;
    CacheLine cacheLines[];
    int[] indtable;
    Processor containingProcessor;
    public Cache(Processor processor,int latency,int cachesize){
        this.containingProcessor=processor;
        this.Latency=latency;
        this.line_size = (int)(this.cachesize/8)/2;
        this.cachesize=cachesize;
        this.cacheLines = new CacheLine[cachesize / 8];
        for(int i=0;i<cachesize/8;i++){
            this.cacheLines[i]=new CacheLine();
        }
    }
    int[] getindexandtag(int address){
        String addr = Integer.toBinaryString(address);
        if (addr.length() < 32) {
            int diff = 32 - addr.length();
            String zeros = "";
            for (int i = 0; i < diff; i++) {
                zeros += "0";
            }
            addr = zeros + addr;
        }
        int tag1=Integer.parseInt(addr.substring(0,addr.length()-this.line_size),2);
        System.out.println("Printing here"+line_size+" "+addr+" till here "+tag1);
        int temp_ind;
        String ind = "0";
        if (line_size == 0)
            temp_ind = 0;
        else
            for (int i = 0; i < line_size; i++)
                ind = ind + "1";
            temp_ind = address & Integer.parseInt(ind, 2);
        return new int[]{tag1,temp_ind};
    }
    int CacheRead(int address){
        int [] indtag=getindexandtag(address);
        int index=indtag[1];
        int tag1=indtag[0];
        System.out.println("Tag is "+tag1);
        int val=cacheLines[index].getdata(tag1);
        if(val==-1){
            hit=false;
            return val;
        }
        else{
            hit=true;
            return val;
        }

        // return 1;
    }
    void CacheWrite(int address,int value){
        int [] indtag=getindexandtag(address);
        int index=indtag[1];
        int tag=indtag[0];
        int val=cacheLines[index].setdata(tag, value);
        if(val==-1){
            hit=false;
            return;
        }
        else{
            hit=true;
            return;
        }
    }
    public int getlatency(){
        return Latency;
    }
    // void handleCacheMiss(int address){
    //     // Simulator.getEventQueue().addEvent(MemoryReadEvent(Clock.getCurrentTime()+Configuration.mainMemoryLatency,this,,address));
    // }
    @Override
    public void handleEvent(Event e){
        if(e.getEventType()==Event.EventType.MemoryRead){
            MemoryReadEvent cachread=(MemoryReadEvent) e;
            int readvalue=CacheRead(cachread.getAddressToReadFrom());
            if(hit==true){
                Simulator.getEventQueue().addEvent(new MemoryResponseEvent(Clock.getCurrentTime()+this.Latency, this, cachread.getRequestingElement(), readvalue));
            }
            else{
                System.out.println("L1 Miss");
                Simulator.getEventQueue().addEvent(new MemoryReadEvent(Clock.getCurrentTime()+Configuration.mainMemoryLatency, this, containingProcessor.getMainMemory(), cachread.getAddressToReadFrom()));
                cachread.setEventTime(Clock.getCurrentTime()+Configuration.mainMemoryLatency);
                Simulator.getEventQueue().addEvent(cachread);
                this.missed_addr=cachread.getAddressToReadFrom();
            }
        }
        else if(e.getEventType()==Event.EventType.MemoryWrite){
            MemoryWriteEvent cachewrite=(MemoryWriteEvent) e;
            CacheWrite(cachewrite.getAddressToWriteTo(), cachewrite.getValue());
            containingProcessor.getMainMemory().setWord(cachewrite.getAddressToWriteTo(), cachewrite.getValue());
            System.out.println("Memory writing "+cachewrite.getValue()+" To "+cachewrite.getAddressToWriteTo());
            Simulator.getEventQueue().addEvent(new ExecutionCompleteEvent(Clock.getCurrentTime()+Configuration.mainMemoryLatency, this, cachewrite.getRequestingElement()));
            
        }
        else if(e.getEventType()==Event.EventType.MemoryResponse){
            MemoryResponseEvent memresp=(MemoryResponseEvent) e;
            CacheWrite(this.missed_addr,memresp.getValue());
        }
    }
}
