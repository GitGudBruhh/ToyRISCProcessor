package processor.memorysystem;

public class CacheLine {
    int[] data=new int[2];
    int[] tag=new int[2];
    int LRU=0;
    public CacheLine() {
        this.tag[0] = -1;
        this.tag[1] = -1;
    }
    public int getdata(int tags) {
        if(tags==this.tag[0]){
            this.LRU=1;
            return this.data[0];
        }
        else if(tags==this.tag[1]){
            this.LRU=0;
            return this.data[1];
        }
        else{
            return -1;
        }
    }
    public int setdata(int tags,int val){
        if(tags==this.tag[0]){
           this.LRU=1;
            this.data[0]=val;
            return 1;
        }
        else if(tags==this.tag[1]){
            this.LRU=0;
            this.data[1]=val;
            return 1;
        }
        else{
            this.tag[LRU]=tags;
            this.data[LRU]=val;
            this.LRU=1-this.LRU;
            return -1;
        }
    }
}
