package processor.pipeline;

import java.util.HashSet;
import java.util.Set;

import generic.Operand;
import processor.Processor;

public class OperandFetch {
	Processor containingProcessor;
	IF_OF_LatchType IF_OF_Latch;
	OF_EX_LatchType OF_EX_Latch;
	
	public OperandFetch(Processor containingProcessor, IF_OF_LatchType iF_OF_Latch, OF_EX_LatchType oF_EX_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_OF_Latch = iF_OF_Latch;
		this.OF_EX_Latch = oF_EX_Latch;
	}
	public static int twoscompliment(String s) {
		char[] chars = s.toCharArray();
		for (int i = 0; i < chars.length; i++) {
			if (chars[i] == '0') {
				chars[i] = '1';
			} else {
				chars[i] = '0';
			}
		}
		String s1 = new String(chars);
		int num = Integer.parseInt(s1, 2);
		num = num + 1;
		return num;
	}
	
	public void performOF()
	{
		if(IF_OF_Latch.isOF_enable())
		{
			//TODO
			

			int in= IF_OF_Latch.getInstruction();
			String inst = Integer.toBinaryString(in);
			if (inst.length() < 32) {	// TODO: check if this is correct
				int diff = 32 - inst.length();
				String zeros = "";
				for (int i = 0; i < diff; i++) {
					zeros += "0";
				}
				inst = zeros + inst;
			}
//			String inst=Integer.toBinaryString(in);
//			System.out.println(inst);
//System.out.println(inst.substring(0, 5));
//			String 
//			Set<Integer> R3= new HashSet<Integer>();
//			Set<Integer> R2I= new HashSet<Integer>();
//			Set<Integer> RI= new HashSet<Integer>();
			
			int code= Integer.parseInt(inst.substring(0, 5),2);
//			System.out.println(code+"stage");
			OF_EX_Latch.setCode(code);
			if(code<22 && code%2==0) {
//				R3 type
				Operand rs1 = new Operand();
				Operand rs2 = new Operand();
				Operand rd = new Operand();
				rs1.setOperandType(Operand.OperandType.Register);
				rs2.setOperandType(Operand.OperandType.Register);
				rd.setOperandType(Operand.OperandType.Register);

				rs1.setValue(Integer.parseInt(inst.substring(5,10),2));
				rs2.setValue(Integer.parseInt(inst.substring(10,15),2));
				rd.setValue(Integer.parseInt(inst.substring(15,20),2));
//				System.out.println("rd in OF "+rd.getValue());
				this.OF_EX_Latch.setOp1(this.containingProcessor.getRegisterFile().getValue(rs1.getValue()));
//				System.out.println("sayonara");
//				System.out.println("Op1 "+containingProcessor.getRegisterFile().getValue(rs1.getValue())+ " rd "+rs1.getValue());
				this.OF_EX_Latch.setOp2(this.containingProcessor.getRegisterFile().getValue(rs2.getValue()));
				this.OF_EX_Latch.setRd(rd);
				this.OF_EX_Latch.setRs1(rs1);
				this.OF_EX_Latch.setRs2(rs2);
//				int rs1=Integer.parseInt(inst.substring(5,10),2);
//				int rs2=Integer.parseInt(inst.substring(10,15),2);
//				int rd=Integer.parseInt(inst.substring(15,20),2);
//				System.out.println(rs1+Integer.parseInt(rs1,2));
//				System.out.println(rs1+" "+rs2+" "+rd);
			}
			else if((code<22 && code%2!=0) || code==22 || code==23 || (code>24 && code<29)) {
//				R2I type
//				System.out.println("here");
				Operand rs1 = new Operand();
				Operand rd = new Operand();
				rs1.setOperandType(Operand.OperandType.Register);
				rd.setOperandType(Operand.OperandType.Register);
				 rs1.setValue(Integer.parseInt(inst.substring(5,10),2));
				 rd.setValue(Integer.parseInt(inst.substring(10,15),2));
//				 System.out.println("rd in OF "+rd.getValue());
				int imx=Integer.parseInt(inst.substring(15,32),2);
//				System.out.println("hello "+ imx);
				if (inst.charAt(15)=='1'){
					imx = -1*twoscompliment(inst.substring(15, 32));
//					System.out.println("h");
//					System.out.println(imx+" immediate");
				}
				this.OF_EX_Latch.setImmx(imx);
				this.OF_EX_Latch.setRs1(rs1);
				this.OF_EX_Latch.setRd(rd);
				this.OF_EX_Latch.setOp1(this.containingProcessor.getRegisterFile().getValue(rs1.getValue()));
//				System.out.println("daijoubu");
//				System.out.println("Op1 "+containingProcessor.getRegisterFile().getValue(rs1.getValue())+ " rd "+rs1.getValue());
				this.OF_EX_Latch.setOp2(this.containingProcessor.getRegisterFile().getValue(rd.getValue()));
//				this.OF_EX_Latch.setImmx(imx);
//				if(code>24 && code<29) {
//					
//				}
//				System.out.println(rs1+Integer.parseInt(rs1,2));
//				System.out.println(rs1+" "+rd+" "+imx);
			}
			else if(code==24){
//				RI type
				Operand op = new Operand();
				String imm = inst.substring(10, 32);
				int imm_val = Integer.parseInt(imm, 2);
				if (imm.charAt(0) == '1'){
					imm_val = -1*twoscompliment(imm);
				}
				if (imm_val != 0){
					op.setOperandType(Operand.OperandType.Immediate);
					op.setValue(imm_val);
//					inst.setSourceOperand1(op);
				}
				else{
					op.setOperandType(Operand.OperandType.Register);
					op.setValue(Integer.parseInt(inst.substring(5, 10), 2));
//					instr.setSourceOperand1(op);
				}
				this.OF_EX_Latch.setImmx(imm_val);
				this.OF_EX_Latch.setRs1(op);
				
			}
			else {
				Operand rd = new Operand();
				rd.setOperandType(Operand.OperandType.Register);
				rd.setValue(Integer.parseInt(inst.substring(5, 10), 2));
				this.OF_EX_Latch.setRd(rd);
//				instr.setDestinationOperand(rd);

				int imm = Integer.parseInt(inst.substring(10, 32), 2); // TODO: 2's complement
				if (inst.charAt(10)=='1'){
					imm = -1*twoscompliment(inst.substring(10, 32));
//					System.out.println(inst);
				}
//				System.out.println("imm: " + imm);
//				OF_EX_Latch.setInstruction(inst);
				OF_EX_Latch.setImmx(imm);
//				this.OF_EX_Latch.setRd(rd);
			}
			
			IF_OF_Latch.setOF_enable(false);
			OF_EX_Latch.setEX_enable(true);
//			System.out.println(false);
		}
	}

}
