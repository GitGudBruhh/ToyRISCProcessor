package processor.pipeline;

import generic.Operand;

public class MA_RW_LatchType {
	
	boolean RW_enable;
	int ldres;
	int alures;
	Operand rd;
	int code;
	
	public Operand getRd() {
		return rd;
	}

	public void setRd(Operand rd) {
		this.rd = rd;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public int getLdres() {
		return ldres;
	}

	public void setLdres(int ldres) {
		this.ldres = ldres;
	}

	public int getAlures() {
		return alures;
	}

	public void setAlures(int alures) {
		this.alures = alures;
	}

	public MA_RW_LatchType()
	{
		RW_enable = false;
	}

	public boolean isRW_enable() {
		return RW_enable;
	}

	public void setRW_enable(boolean rW_enable) {
		RW_enable = rW_enable;
	}

}
