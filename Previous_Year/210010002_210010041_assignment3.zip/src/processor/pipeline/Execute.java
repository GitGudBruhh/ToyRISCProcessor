package processor.pipeline;

import generic.Operand;
import processor.Processor;
import generic.Simulator;

public class Execute {
	Processor containingProcessor;
	OF_EX_LatchType OF_EX_Latch;
	EX_MA_LatchType EX_MA_Latch;
	EX_IF_LatchType EX_IF_Latch;
	
	public Execute(Processor containingProcessor, OF_EX_LatchType oF_EX_Latch, EX_MA_LatchType eX_MA_Latch, EX_IF_LatchType eX_IF_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.OF_EX_Latch = oF_EX_Latch;
		this.EX_MA_Latch = eX_MA_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}
	
	public void performEX()
	{
//		System.out.println("Entered exec");
		if(OF_EX_Latch.isEX_enable()) {
		int code=this.OF_EX_Latch.getCode();
		Operand rs1=this.OF_EX_Latch.getRs1();
		Operand rs2=this.OF_EX_Latch.getRs2();
		Operand rd=this.OF_EX_Latch.getRd();
//		System.out.println("rd in EX "+rd.getValue());
//		System.out.println(containingProcessor.getRegisterFile().getValue(3)+" is here And rd is "+rd.getValue());
		int op1=this.OF_EX_Latch.getOp1();
		int op2=this.OF_EX_Latch.getOp2();
		int imx=this.OF_EX_Latch.getImmx();
		int cur_pc=this.containingProcessor.getRegisterFile().getProgramCounter();
		int alures = 0;
		boolean skipma=false;
//		System.out.println(code+"op1 "+op1+" op2 "+op2);
		switch(code) {
		case 0:
			alures=op1+op2;break;
		case 1:
			alures=op1+imx;
//			System.out.println("Add is "+op1+" "+imx+" "+alures);
			break;
		case 2:
			alures=op1-op2;break;
		case 3:
			alures=op1-imx;break;
		case 4:
			alures=op1*op2;break;	
		case 5:
			alures=op1*imx;break;
		case 6:
			alures=op1/op2;this.containingProcessor.getRegisterFile().setValue(31, op1 % op2);break;	
		case 7:
//			System.out.println("divi here "+op1+" "+op2);
			alures=op1/imx;this.containingProcessor.getRegisterFile().setValue(31, op1 % imx);break;	
		case 8:
			alures=op1&op2;break;	
		case 9:
			alures=op1&imx;break;
		case 10:
			alures=op1|op2;break;
		case 11:
			alures=op1|imx;break;	
		case 12:
			alures=op1^op2;break;
		case 13:
			alures=op1^imx;break;
		case 14:
			alures=(op1 < op2) ? 1 : 0;break;	
		case 15:
			alures=(op1 < imx) ? 1 : 0;break;	
		case 16:
			alures=op1<<op2;break;	
		case 17:
			alures=op1<<imx;break;	
		case 18:
			alures=op1>>>op2;break;	
		case 19:
			alures=op1>>>imx;break;
		case 20:
			alures=op1>>op2;break;	
		case 21:
			alures=op1>>imx;break;
		case 22:
			alures=op1+imx;break;
		case 23:
			alures=op2+imx;break;
		case 24:
			int target;
			if(rs1.getOperandType()==Operand.OperandType.Register) {
				 target=this.containingProcessor.getRegisterFile().getValue(rs1.getValue());
			}
			else {
				target=imx;
			}
			alures = cur_pc + target ;
			EX_IF_Latch.setIF_enable(true);
			skipma=true;
			EX_IF_Latch.setBranch_target(alures);break;
		case 25:
//			System.out.println("beq here"+op1+" "+op2);
			if(op1==op2) {
				alures = cur_pc + imx ;
//				System.out.println("HI");
				EX_IF_Latch.setIF_enable(true);
				EX_IF_Latch.setBranch_target(alures);
				skipma=true;
			}break;
		case 26:
			if(op1!=op2) {
				alures = cur_pc + imx ;
				EX_IF_Latch.setIF_enable(true);
				EX_IF_Latch.setBranch_target(alures);
				skipma=true;
			}break;
		case 27:
			if(op1<op2) {
//				System.out.println("blt here"+op1+" "+op2);
				alures = cur_pc + imx ;
				EX_IF_Latch.setIF_enable(true);
				EX_IF_Latch.setBranch_target(alures);
				skipma=true;
			}break;
		case 28:
			if(op1>op2) {
				alures = cur_pc + imx ;
				EX_IF_Latch.setIF_enable(true);
				EX_IF_Latch.setBranch_target(alures);
				skipma=true;
			}break;
		case 29:
			Simulator.setSimulationComplete(true);break;
		}
//		System.out.println("ALU RESULT: " + alures+"\n\n");
		//TODO
		EX_MA_Latch.setAlures(alures);
		EX_MA_Latch.setCode(code);
		EX_MA_Latch.setRd(rd);
		EX_MA_Latch.setRs1(rs1);
		if(!skipma) {
			this.EX_MA_Latch.setMA_enable(true);
		}
	}
		this.OF_EX_Latch.setEX_enable(false);
		
		
	}
	
}
