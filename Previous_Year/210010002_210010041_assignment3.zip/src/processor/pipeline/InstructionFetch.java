package processor.pipeline;

import processor.Processor;

public class InstructionFetch {
	
	Processor containingProcessor;
	IF_EnableLatchType IF_EnableLatch;
	IF_OF_LatchType IF_OF_Latch;
	EX_IF_LatchType EX_IF_Latch;
	
	public InstructionFetch(Processor containingProcessor, IF_EnableLatchType iF_EnableLatch, IF_OF_LatchType iF_OF_Latch, EX_IF_LatchType eX_IF_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_EnableLatch = iF_EnableLatch;
		this.IF_OF_Latch = iF_OF_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}
	
	public void performIF()
	{	
		if(EX_IF_Latch.getIF_enable() ) {
//			System.out.println("Arigatou");
			this.containingProcessor.getRegisterFile().setProgramCounter(EX_IF_Latch.getBranch_target()-1);
//			IF_EnableLatch.setIF_enable(false);
//			IF_OF_Latch.setOF_enable(true);
//			EX_IF_Latch.setIF_enable(false);
		}
		if(IF_EnableLatch.isIF_enable()|| EX_IF_Latch.getIF_enable())
		{
			int currentPC = containingProcessor.getRegisterFile().getProgramCounter();
			int newInstruction = containingProcessor.getMainMemory().getWord(currentPC);
			IF_OF_Latch.setInstruction(newInstruction);
			
//			System.out.println("ProgramCount"+currentPC);
//			System.out.println("The element is"+containingProcessor.getRegisterFile().getValue(3));
//			
////			System.out.println("new inst set as "+ newInstruction);
////			System.out.println(containingProcessor.getRegisterFile().getValue(3));
			this.containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);
			
			IF_EnableLatch.setIF_enable(false);
			IF_OF_Latch.setOF_enable(true);
			EX_IF_Latch.setIF_enable(false);
		}
		
	}

}
