package generic;

import processor.Clock;
import processor.Processor;
import processor.memorysystem.MainMemory;

import java.io.*;

public class Simulator {
		
	static Processor processor;
	static boolean simulationComplete;
	private static final int BUFFER_SIZE = 4;
	
	public static void setupSimulation(String assemblyProgramFile, Processor p)
	{
		Simulator.processor = p;
		loadProgram(assemblyProgramFile);
		
		simulationComplete = false;
	}
	
	static void loadProgram(String assemblyProgramFile)
	{
		/*
		 * TODO
		 * 1. load the program into memory according to the program layout described
		 *    in the ISA specification
		 * 2. set PC to the address of the first instruction in the main
		 * 3. set the following registers:
		 *     x0 = 0
		 *     x1 = 65535
		 *     x2 = 65535
		 */
		try (
	            InputStream inputStream = new FileInputStream(assemblyProgramFile);
//	            OutputStream outputStream = new FileOutputStream(outputFile);
	        ) {
			DataInputStream d_is = new DataInputStream(inputStream);
			int address = -1;
			MainMemory mem= new MainMemory();
		while(d_is.available() > 0){
			int next = d_is.readInt();
			if(address==-1 ) {
				processor.getRegisterFile().setProgramCounter(next);
				address++;
			}
			else {
//				String n1=Integer.toBinaryString(next);
				mem.setWord(address, next);
//				System.out.println(next);
				address++;
			}
	 
	        }
		processor.setMainMemory(mem);
		processor.getRegisterFile().setValue(0, 0);
		processor.getRegisterFile().setValue(1, 65535);
		processor.getRegisterFile().setValue(2, 65535);
		} catch (IOException ex) {
	            ex.printStackTrace();
	        }
		
	}
	
	public static void simulate()
	{
		while(simulationComplete == false)
		{
			
			processor.getRWUnit().performRW();
//			System.out.println("RWcalled");
			processor.getMAUnit().performMA();
//			System.out.println("MAcalled");
			processor.getEXUnit().performEX();
//			System.out.println("EXcalled");
			processor.getOFUnit().performOF();
//			System.out.println("Ofcalled");
			processor.getIFUnit().performIF();
//			System.out.println("IFcalled");
//			Clock.incrementClock();
			
//			Clock.incrementClock();
			
//			Clock.incrementClock();
			
//			Clock.incrementClock();
			
			Clock.incrementClock();
//			Statistics.setNumberOfInstructions(Statistics.getNumberOfInstructions()+1);
			Statistics.setNumberOfCycles(Statistics.getNumberOfCycles()+1);
		}
		
		// TODO
		// set statistics
	}
	
	public static void setSimulationComplete(boolean value)
	{
		simulationComplete = value;
	}
}
