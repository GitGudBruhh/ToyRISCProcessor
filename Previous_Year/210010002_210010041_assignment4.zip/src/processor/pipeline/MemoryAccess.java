package processor.pipeline;

import processor.Processor;

public class MemoryAccess {
	Processor containingProcessor;
	EX_MA_LatchType EX_MA_Latch;
	MA_RW_LatchType MA_RW_Latch;
	
	public MemoryAccess(Processor containingProcessor, EX_MA_LatchType eX_MA_Latch, MA_RW_LatchType mA_RW_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.EX_MA_Latch = eX_MA_Latch;
		this.MA_RW_Latch = mA_RW_Latch;
	}
	
	public void performMA()
	{
		//TODO
		if(EX_MA_Latch.isMA_enable()) {
		int code=EX_MA_Latch.getCode();
		int alures=EX_MA_Latch.getAlures();
		int ldres;
		if(code==22) {
			
			ldres=this.containingProcessor.getMainMemory().getWord(alures);
//			System.out.println("Loading "+ldres+ " into "+alures);
			MA_RW_Latch.setLdres(ldres);
		}
		else if(code==23) {
			this.containingProcessor.getMainMemory().setWord(alures,this.containingProcessor.getRegisterFile().getValue(EX_MA_Latch.getRs1().getValue()));
//			System.out.println("Storing "+alures + " at "+this.containingProcessor.getRegisterFile().getValue(EX_MA_Latch.getRd().getValue()));
		}
		else if(code==29) {
			EX_MA_Latch.setMA_enable(false);
		}
		MA_RW_Latch.setRW_enable(true);
//		EX_MA_Latch.setMA_enable(false);
		MA_RW_Latch.setAlures(alures);
		MA_RW_Latch.setCode(code);
		MA_RW_Latch.setRd(EX_MA_Latch.getRd());
		
		}
	}

}
