package processor.pipeline;

public class IF_EnableLatchType {
	
	boolean IF_enable;
	boolean IF_stall;
	
	public boolean isIF_stall() {
		return IF_stall;
	}

	public void setIF_stall(boolean iF_stall) {
		IF_stall = iF_stall;
	}

	public IF_EnableLatchType()
	{
		IF_enable = true;
	}

	public boolean isIF_enable() {
		return IF_enable;
	}

	public void setIF_enable(boolean iF_enable) {
		IF_enable = iF_enable;
	}

}
