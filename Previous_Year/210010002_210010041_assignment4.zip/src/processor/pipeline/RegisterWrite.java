package processor.pipeline;

import generic.Operand;
import generic.Simulator;
import processor.Processor;

public class RegisterWrite {
	Processor containingProcessor;
	MA_RW_LatchType MA_RW_Latch;
	IF_EnableLatchType IF_EnableLatch;
	
	public RegisterWrite(Processor containingProcessor, MA_RW_LatchType mA_RW_Latch, IF_EnableLatchType iF_EnableLatch)
	{
		this.containingProcessor = containingProcessor;
		this.MA_RW_Latch = mA_RW_Latch;
		this.IF_EnableLatch = iF_EnableLatch;
	}
	
	public void performRW()
	{
//		System.out.println("RW");
		if(MA_RW_Latch.isRW_enable())
		{
			//TODO
			int code=MA_RW_Latch.getCode();
			Operand rd=MA_RW_Latch.getRd();
			int alures=MA_RW_Latch.getAlures();
			int ldres= MA_RW_Latch.getLdres();
			if(code<22) {
//				System.out.println("RegisterWriteloginif "+containingProcessor.getRegisterFile().getValue(3)+"The rd which we are storing "+rd.getValue());
				this.containingProcessor.getRegisterFile().setValue(rd.getValue(), alures);
			}
			else if(code==22) {
				this.containingProcessor.getRegisterFile().setValue(rd.getValue(),ldres );
//				System.out.println("Loaded "+ldres + " into "+ rd.getValue()+" as "+this.containingProcessor.getRegisterFile().getValue(3));
			}
			else if(code==29) {
				Simulator.setSimulationComplete(true);
				System.out.println(this.containingProcessor.getRegisterFile().getProgramCounter());
				this.containingProcessor.getRegisterFile().setProgramCounter(this.containingProcessor.getRegisterFile().getProgramCounter()-1);;
				MA_RW_Latch.setRW_enable(false);
			}
//			System.out.println("RegisterWritelog "+containingProcessor.getRegisterFile().getValue(3));
			
			// if instruction being processed is an end instruction, remember to call Simulator.setSimulationComplete(true);
			
//			MA_RW_Latch.setRW_enable(false);
//			IF_EnableLatch.setIF_enable(true);
		}
	}

}
