package processor.pipeline;

import generic.Operand;

public class OF_EX_LatchType {
	
	boolean EX_enable;
	Operand rs1;
	Operand rs2;
	Operand rd;
	int op1;
	int op2;
	int immx;
	int code;
	public OF_EX_LatchType()
	{
		EX_enable = false;
	}

	public Operand getRs1() {
		return rs1;
	}

	public void setRs1(Operand rs1) {
		this.rs1 = rs1;
	}

	public Operand getRs2() {
		return rs2;
	}

	public void setRs2(Operand rs2) {
		this.rs2 = rs2;
	}

	public Operand getRd() {
		return rd;
	}

	public void setRd(Operand rd) {
		this.rd = rd;
	}

	public int getOp1() {
		return op1;
	}

	public void setOp1(int op1) {
		this.op1 = op1;
	}

	public int getOp2() {
		return op2;
	}

	public void setOp2(int op2) {
		this.op2 = op2;
	}

	public int getCode() {
		return code;
	}

	public int getImmx() {
		return immx;
	}

	public void setImmx(int immx) {
		this.immx = immx;
	}

	public void setCode(int code) {
		this.code = code;
	}

	

	public boolean isEX_enable() {
		return EX_enable;
	}

	public void setEX_enable(boolean eX_enable) {
		EX_enable = eX_enable;
	}

}
