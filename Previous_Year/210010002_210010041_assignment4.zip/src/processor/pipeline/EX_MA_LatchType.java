package processor.pipeline;

import generic.Operand;

public class EX_MA_LatchType {
	
	boolean MA_enable;
	int alures;
	int code;
	Operand rd;
	Operand rs1;
	
	public Operand getRs1() {
		return rs1;
	}

	public void setRs1(Operand rs1) {
		this.rs1 = rs1;
	}

	public Operand getRd() {
		return rd;
	}

	public void setRd(Operand rd) {
		this.rd = rd;
	}

	public int getAlures() {
		return alures;
	}

	public void setAlures(int alures) {
		this.alures = alures;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public EX_MA_LatchType()
	{
		MA_enable = false;
	}

	public boolean isMA_enable() {
		return MA_enable;
	}

	public void setMA_enable(boolean mA_enable) {
		MA_enable = mA_enable;
	}

}
