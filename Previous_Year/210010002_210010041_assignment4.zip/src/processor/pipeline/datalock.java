package processor.pipeline;

import generic.Operand;

public class datalock{
	
}