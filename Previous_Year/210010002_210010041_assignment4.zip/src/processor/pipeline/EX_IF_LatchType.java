package processor.pipeline;

public class EX_IF_LatchType {
	boolean IF_enable;
	int branch_target;
	boolean istaken;
	
	public int getBranch_target() {
		return branch_target;
	}
	public void setBranch_target(int branch_target) {
		this.branch_target = branch_target;
	}
	public boolean isIstaken() {
		return istaken;
	}
	public void setIstaken(boolean istaken) {
		this.istaken = istaken;
	}
	public EX_IF_LatchType()
	{
		
	}
	public boolean getIF_enable() {
		return IF_enable;
	}
	public void setIF_enable(boolean t) {
		IF_enable=t;
	}

}
