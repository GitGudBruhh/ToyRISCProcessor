package generic;

// import java.io.FileInputStream;
// import java.io.FileOutputStream;
import java.io.*;
import java.nio.*;
import generic.Operand.OperandType;


public class Simulator {
		
	static FileInputStream inputcodeStream = null;
	static int fcAddress;
	
	public static void setupSimulation(String assemblyProgramFile)
	{	
		int firstCodeAddress = ParsedProgram.parseDataSection(assemblyProgramFile);
		fcAddress = firstCodeAddress; //Custom Addition: Set variable in class to firstCodeAddress. Will be used to write into file
		ParsedProgram.parseCodeSection(assemblyProgramFile, firstCodeAddress);
		ParsedProgram.printState();
	}
	
	public static void assemble(String objectProgramFile)
	{
		//TODO your assembler code

		//============================================================
		//1. open the objectProgramFile in binary mode
		//============================================================

		try {
			FileOutputStream oStreamObjProgFile = new FileOutputStream(objectProgramFile);

			try {
		//============================================================
		//2. write the firstCodeAddress to the file
		//============================================================

				//REFER TO THIS: 	https://stackoverflow.com/questions/2183240/java-integer-to-byte-array
				//					https://docs.oracle.com/javase/6/docs/api/java/nio/ByteBuffer.html

				byte[] bytesToWrite = ByteBuffer.allocate(4).putInt(fcAddress).array();
					oStreamObjProgFile.write(bytesToWrite);


		//============================================================
		//3. write the data to the file
		//============================================================
				int dataArrayListSize = ParsedProgram.data.size();

				Integer currentData;
				for(int idx = 0; idx < dataArrayListSize; idx++) {
					currentData = ParsedProgram.data.get(idx); //Returns one line of data as Integer

					bytesToWrite = ByteBuffer.allocate(4).putInt(currentData.intValue()).array();
					oStreamObjProgFile.write(bytesToWrite);
				}


		//============================================================
		//4. assemble one instruction at a time, and write to the file
		//============================================================
				int codeArrayListSize = ParsedProgram.code.size();

				Instruction currentInstruction;

				Operand currentSourceOpnd1;
				Operand currentSourceOpnd2;
				Operand currentDestOpnd;

				Operand.OperandType opndTypeRs1;
				Operand.OperandType opndTypeRs2;
				Operand.OperandType opndTypeRd;

				for(int idx = 0; idx < codeArrayListSize; idx++) {
					currentInstruction = ParsedProgram.code.get(idx); //Returns one line of data as Instruction

					//Get all source operands (returns null if unused)
					currentSourceOpnd1 = currentInstruction.getSourceOperand1();
					currentSourceOpnd2 = currentInstruction.getSourceOperand2();
					currentDestOpnd = currentInstruction.getDestinationOperand();

					//Copy instruction type {add, addi, sub, ...}
					Instruction.OperationType currentOperationType = currentInstruction.getOperationType();

					//Copy operand types {Register, Immediate, Label}
					opndTypeRs1 = (currentSourceOpnd1 == null) ? null : currentSourceOpnd1.getOperandType();
					opndTypeRs2 = (currentSourceOpnd2 == null) ? null : currentSourceOpnd2.getOperandType();
					opndTypeRd = (currentDestOpnd == null) ? null : currentDestOpnd.getOperandType();

					/*
					For any arithmetic operation, imm values/label are kept in sourceOpnd2
					Opcodes: 0 -> 21 (Odd no.s)

					For loads and stores, imm values/label
					imm values are kept in sourceOpnd2
					Opcodes: 22, 23

					In jmp statements, either imm/label = 0, or rd = 0.
					The non zero value is kept in destOpnd
					Opcode: 24

					In conditional branches, sourceOpnd1 is compared to sourceOpnd2; immediate/label
					is in destOpnd.
					Opcodes: 25 -> 28

					In end instruction, rd and imm are unused
					Opcode: 29

					So, imm values (as labels), can be in destOpnd, sourceOpnd2, but never sourceOpnd1
					*/

					int currentInstructionAsInt = 0;

					//Convert operation to opcode(int) and shift left
					currentInstructionAsInt += (currentOperationType.ordinal() << 27);

					/*Convert source and destination operands to int and shift left*/
					//RI (jmp & end)
					if(currentSourceOpnd1 == null) {

						//jmp
						/*
						NOTE:
						The Parser keeps the used value (immediate/label vs rd) automatically in
						destinationOperand. So we do not need to check the type of any other variable
						*/
						if(currentInstruction.getOperationType() == Instruction.OperationType.jmp) {

							//Label
							if(opndTypeRd == Operand.OperandType.Label) {
								Integer addrOfLabel = ParsedProgram.symtab.get(currentDestOpnd.getLabelValue());
								int signedOffset = addrOfLabel.intValue() - currentInstruction.getProgramCounter();
								int signedTruncatedOffset = signedOffset & ((1 << 22) - 1);
								currentInstructionAsInt += signedTruncatedOffset;
							}

							//Immediate
							else if(opndTypeRd == Operand.OperandType.Immediate) {
								currentInstructionAsInt += currentDestOpnd.getValue();
							}

							//Register
							else
								currentInstructionAsInt += (currentDestOpnd.getValue() << 22);

						}

						//end
						// else if(currentInstruction.getOperationType() == Instruction.OperationType.end) {
						// 	currentInstructionAsInt += 0;
						// }
					}

					//R3 or R2I type
					else {

						Integer addrOfLabel;
						Integer valAtLabel;

						//Label to addrOfLabel to valAtLabel
						// if(opndTypeRs2 == Operand.OperandType.Label) {
						// 	addrOfLabel = ParsedProgram.symtab.get(currentSourceOpnd2.getLabelValue());
						// 	valAtLabel = ParsedProgram.data.get(addrOfLabel.intValue());
						// }

						//R3
						if(
						opndTypeRs1 == Operand.OperandType.Register &&
						opndTypeRs2 == Operand.OperandType.Register &&
						opndTypeRd == Operand.OperandType.Register) {

							currentInstructionAsInt += (currentSourceOpnd1.getValue() << 22);
							currentInstructionAsInt += (currentSourceOpnd2.getValue() << 17);
							currentInstructionAsInt += (currentDestOpnd.getValue() << 12);
						}

						//R2I Arithmetic/LoadStore - Immediate
						if(
						opndTypeRs1 == Operand.OperandType.Register &&
						opndTypeRs2 == Operand.OperandType.Immediate &&
						opndTypeRd == Operand.OperandType.Register) {

							currentInstructionAsInt += (currentSourceOpnd1.getValue() << 22);
							currentInstructionAsInt += currentSourceOpnd2.getValue();
							currentInstructionAsInt += (currentDestOpnd.getValue() << 17);
						}


						//R2I Arithmetic/LoadStore - Label
						if(
						opndTypeRs1 == Operand.OperandType.Register &&
						opndTypeRs2 == Operand.OperandType.Label &&
						opndTypeRd == Operand.OperandType.Register) {

							currentInstructionAsInt += (currentSourceOpnd1.getValue() << 22);

							//Arithmetic
							if(currentOperationType.ordinal() <= 21) {
								addrOfLabel = ParsedProgram.symtab.get(currentSourceOpnd2.getLabelValue());
								valAtLabel = ParsedProgram.data.get(addrOfLabel.intValue());
								currentInstructionAsInt += valAtLabel.intValue();
							}

							//LoadStore
							else {
								addrOfLabel = ParsedProgram.symtab.get(currentSourceOpnd2.getLabelValue());
								currentInstructionAsInt += addrOfLabel.intValue();
							}

							currentInstructionAsInt += (currentDestOpnd.getValue() << 17);
						}

						//R2I Conditional Branches - Immediate
						if(
						opndTypeRs1 == Operand.OperandType.Register &&
						opndTypeRs2 == Operand.OperandType.Register &&
						opndTypeRd == Operand.OperandType.Immediate) {

							currentInstructionAsInt += (currentSourceOpnd1.getValue() << 22);
							currentInstructionAsInt += (currentSourceOpnd2.getValue() << 17);
							currentInstructionAsInt += currentDestOpnd.getValue();
						}

						//R2I Conditional Branches - Label
						if(
						opndTypeRs1 == Operand.OperandType.Register &&
						opndTypeRs2 == Operand.OperandType.Register &&
						opndTypeRd == Operand.OperandType.Label) {

							currentInstructionAsInt += (currentSourceOpnd1.getValue() << 22);

							currentInstructionAsInt += (currentSourceOpnd2.getValue() << 17);

							addrOfLabel = ParsedProgram.symtab.get(currentDestOpnd.getLabelValue());
							int signedOffset = addrOfLabel.intValue() - currentInstruction.getProgramCounter();
							int signedTruncatedOffset = signedOffset & ((1 << 17) - 1);
							currentInstructionAsInt += signedTruncatedOffset;
						}

					}

					bytesToWrite = ByteBuffer.allocate(4).putInt(currentInstructionAsInt).array();
					oStreamObjProgFile.write(bytesToWrite);
				}

		//============================================================
		//5. close the file
		//============================================================

				oStreamObjProgFile.close();
			}
			catch (IOException e) {
				System.out.print("File Write Exception");
			}
		}
		catch(FileNotFoundException e) {
			Misc.printErrorAndExit(e.toString());
		}
	}
	
}
