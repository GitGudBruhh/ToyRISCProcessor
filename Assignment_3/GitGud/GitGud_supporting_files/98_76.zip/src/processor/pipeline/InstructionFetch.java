package processor.pipeline;

import processor.Processor;

public class InstructionFetch {
	
	Processor containingProcessor;
	IF_EnableLatchType IF_EnableLatch;
	IF_OF_LatchType IF_OF_Latch;
	EX_IF_LatchType EX_IF_Latch;
	
	public InstructionFetch(Processor containingProcessor, IF_EnableLatchType iF_EnableLatch, IF_OF_LatchType iF_OF_Latch, EX_IF_LatchType eX_IF_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_EnableLatch = iF_EnableLatch;
		this.IF_OF_Latch = iF_OF_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}
	
	public void performIF()
	{
		if(IF_EnableLatch.isIF_enable())
		{
			ControlSignals controlSignals = EX_IF_Latch.getControlSignals();
			RegisterFile regFileCopy = containingProcessor.getRegisterFile();
			int currentPC = regFileCopy.getProgramCounter();


			/*
			An idle processor denotes the start of a program, and an end instruction sets the processor to idle.
			A non idle processor continues with the execution
			*/
			if(containingProcessor.isIdle())
				containingProcessor.setIdle(false);

			/*
			If the previous instruction was an end instruction, just set the processor to an idle state.
			The instructuons are
			*/
			if(controlSignals.getControlSignal(ControlSignals.OperationSignals.END.ordinal())) {
				// int instruction = containingProcessor.getMainMemory().getWord(currentPC);
				// IF_OF_Latch.setInstruction(instruction);
				// IF_OF_Latch.setPc(currentPC);

				// regFileCopy.setProgramCounter(currentPC);
				// containingProcessor.setRegisterFile(regFileCopy);

				IF_OF_Latch.setOF_enable(true);
				IF_EnableLatch.setIF_enable(false);

				containingProcessor.setIdle(true);
				return;
			}
			else {
				int branchPC = EX_IF_Latch.getBranchPC();

				if(controlSignals.getControlSignal(ControlSignals.OperationSignals.BRANCHTAKEN.ordinal())) {
					int instruction = containingProcessor.getMainMemory().getWord(branchPC);
					IF_OF_Latch.setInstruction(instruction);
					IF_OF_Latch.setPc(branchPC);

					regFileCopy.setProgramCounter(branchPC + 1);
					containingProcessor.setRegisterFile(regFileCopy);

					IF_OF_Latch.setOF_enable(true);
					IF_EnableLatch.setIF_enable(false);
				}
				else {
					int instruction = containingProcessor.getMainMemory().getWord(currentPC);
					IF_OF_Latch.setInstruction(instruction);
					IF_OF_Latch.setPc(currentPC);

					regFileCopy.setProgramCounter(currentPC + 1);
					containingProcessor.setRegisterFile(regFileCopy);

					IF_OF_Latch.setOF_enable(true);
					IF_EnableLatch.setIF_enable(false);
				}
			}
		}
	}

}
