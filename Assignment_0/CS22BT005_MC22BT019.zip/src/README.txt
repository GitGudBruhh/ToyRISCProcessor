A pre-generated output.txt is kept in this folder

To re-run the simulation for the data, delete the current output.txt, adjust the parameters in the main.ipynb file and run the cells.
